"use client";

import React, { useState } from "react";
import {
  Menu,
  X,
  BarChart3,
  Package,
  Truck,
  List,
  Settings,
  Home,
} from "lucide-react";

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const pathname =
    typeof window !== "undefined" ? window.location.pathname : "";

  const navItems = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/produtos", icon: Package, label: "Produtos" },
    { href: "/estoque", icon: Truck, label: "Estoque" },
    { href: "/movimentacoes", icon: List, label: "Movimentações" },
    { href: "/relatorios", icon: BarChart3, label: "Relatórios" },
    { href: "/configuracoes", icon: Settings, label: "Configurações" },
  ];

  const isActive = (href) => {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 md:hidden p-2 bg-[#05204B] text-[#FAFEFE] rounded-lg"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-screen w-64 bg-[#05204B] text-[#FAFEFE] z-40 transition-transform duration-300 md:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-[#4675AF]">
            <h1 className="text-2xl font-bold text-[#4675AF]">SGE</h1>
            <p className="text-xs text-[#FAFEFE] opacity-75">
              Sistema de Gestão de Estoque
            </p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    onClick={() => setIsOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive(item.href)
                        ? "bg-[#4675AF] text-[#FAFEFE]"
                        : "text-[#FAFEFE] hover:bg-[#4675AF] hover:bg-opacity-30"
                    }`}
                  >
                    <item.icon size={20} />
                    <span>{item.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-[#4675AF]">
            <p className="text-xs text-[#FAFEFE] opacity-50">SGE v1.0</p>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
