"use client";

import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Package,
  DollarSign,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import { useState } from "react";

export default function Dashboard() {
  const [dateRange, setDateRange] = useState("week");

  const {
    data: reports,
    isLoading: reportsLoading,
    error: reportsError,
  } = useQuery({
    queryKey: ["reports"],
    queryFn: async () => {
      const response = await fetch("/api/reports");
      if (!response.ok) throw new Error("Erro ao buscar relatórios");
      return response.json();
    },
  });

  if (reportsLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4675AF] mx-auto"></div>
          <p className="mt-4 text-[#05204B]">Carregando...</p>
        </div>
      </div>
    );
  }

  if (reportsError) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">Erro ao carregar dados</p>
      </div>
    );
  }

  const stats = [
    {
      label: "Total de Produtos",
      value: reports?.totalProducts || 0,
      icon: Package,
      color: "bg-[#4675AF]",
      textColor: "text-[#4675AF]",
    },
    {
      label: "Valor Total em Estoque",
      value: `R$ ${(reports?.totalStockValue || 0).toLocaleString("pt-BR", { maximumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: "bg-green-500",
      textColor: "text-green-500",
    },
    {
      label: "Produtos Abaixo do Mínimo",
      value: reports?.productsBelow || 0,
      icon: AlertTriangle,
      color: "bg-red-500",
      textColor: "text-red-500",
    },
    {
      label: "Entradas Hoje",
      value: reports?.enteredToday || 0,
      icon: TrendingUp,
      color: "bg-blue-500",
      textColor: "text-blue-500",
    },
    {
      label: "Saídas Hoje",
      value: reports?.exitedToday || 0,
      icon: TrendingDown,
      color: "bg-orange-500",
      textColor: "text-orange-500",
    },
  ];

  // Prepare chart data
  const chartData =
    reports?.chartData?.reduce((acc, item) => {
      const date = new Date(item.date).toLocaleDateString("pt-BR", {
        month: "2-digit",
        day: "2-digit",
      });
      const existing = acc.find((d) => d.date === date);

      if (existing) {
        if (item.type === "entrada") existing.entrada = item.total;
        if (item.type === "saida") existing.saida = item.total;
      } else {
        acc.push({
          date,
          [item.type]: item.total,
        });
      }

      return acc;
    }, []) || [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#05204B]">Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Bem-vindo ao Sistema de Gestão de Estoque
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 border-l-4"
              style={{
                borderColor:
                  stat.color.split("-")[1] === "[#4675AF]"
                    ? "#4675AF"
                    : "inherit",
              }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">
                    {stat.label}
                  </p>
                  <p className={`text-2xl font-bold mt-2 ${stat.textColor}`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg opacity-10`}>
                  <Icon size={24} className={stat.textColor} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Line Chart */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={20} className="text-[#4675AF]" />
            <h2 className="text-lg font-bold text-[#05204B]">
              Movimentações por Dia
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData.slice(-7)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="entrada"
                stroke="#3b82f6"
                name="Entradas"
              />
              <Line
                type="monotone"
                dataKey="saida"
                stroke="#f97316"
                name="Saídas"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Bar Chart */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={20} className="text-[#4675AF]" />
            <h2 className="text-lg font-bold text-[#05204B]">
              Comparativo de Movimentações
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData.slice(-7)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="entrada" fill="#3b82f6" name="Entradas" />
              <Bar dataKey="saida" fill="#f97316" name="Saídas" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Movements */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-bold text-[#05204B] mb-4">
          Últimas Movimentações
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-[#4675AF]">
                <th className="text-left px-4 py-2 font-semibold text-[#05204B]">
                  Produto
                </th>
                <th className="text-left px-4 py-2 font-semibold text-[#05204B]">
                  Tipo
                </th>
                <th className="text-left px-4 py-2 font-semibold text-[#05204B]">
                  Quantidade
                </th>
                <th className="text-left px-4 py-2 font-semibold text-[#05204B]">
                  Data
                </th>
              </tr>
            </thead>
            <tbody>
              {chartData.length === 0 ? (
                <tr>
                  <td colSpan="4" className="text-center py-4 text-gray-500">
                    Nenhuma movimentação registrada
                  </td>
                </tr>
              ) : (
                chartData.slice(0, 5).map((item, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{item.product_name || "-"}</td>
                    <td className="px-4 py-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          item.type === "entrada"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-orange-100 text-orange-800"
                        }`}
                      >
                        {item.type === "entrada" ? "Entrada" : "Saída"}
                      </span>
                    </td>
                    <td className="px-4 py-2">{item.quantity}</td>
                    <td className="px-4 py-2">
                      {new Date(item.movement_date).toLocaleDateString("pt-BR")}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
