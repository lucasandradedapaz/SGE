"use client";

import { useQuery } from "@tanstack/react-query";
import { BarChart3, Calendar } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { useState } from "react";

export default function Relatorios() {
  const [startDate, setStartDate] = useState(
    new Date(new Date().setDate(new Date().getDate() - 30))
      .toISOString()
      .split("T")[0],
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0],
  );

  const { data: reports, isLoading } = useQuery({
    queryKey: ["reports", startDate, endDate],
    queryFn: async () => {
      const url = new URL("/api/reports", window.location.origin);
      if (startDate) url.searchParams.append("startDate", startDate);
      if (endDate) url.searchParams.append("endDate", endDate);

      const response = await fetch(url);
      if (!response.ok) throw new Error("Erro ao buscar relatórios");
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4675AF] mx-auto"></div>
          <p className="mt-4 text-[#05204B]">Carregando...</p>
        </div>
      </div>
    );
  }

  // Prepare chart data
  const chartData =
    reports?.chartData?.reduce((acc, item) => {
      const date = new Date(item.date).toLocaleDateString("pt-BR", {
        month: "2-digit",
        day: "2-digit",
      });
      const existing = acc.find((d) => d.date === date);

      if (existing) {
        if (item.type === "entrada") existing.entrada = item.total;
        if (item.type === "saida") existing.saida = item.total;
      } else {
        acc.push({
          date,
          [item.type]: item.total,
        });
      }

      return acc;
    }, []) || [];

  const pieLabelData = [
    {
      name: "Entradas",
      value:
        reports?.chartData
          ?.filter((d) => d.type === "entrada")
          .reduce((sum, d) => sum + d.total, 0) || 0,
      fill: "#3b82f6",
    },
    {
      name: "Saídas",
      value:
        reports?.chartData
          ?.filter((d) => d.type === "saida")
          .reduce((sum, d) => sum + d.total, 0) || 0,
      fill: "#f97316",
    },
  ];

  const COLORS = ["#3b82f6", "#f97316"];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#05204B]">Relatórios</h1>
        <p className="text-gray-600 mt-2">Análise completa do seu estoque</p>
      </div>

      {/* Date Filter */}
      <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-[#4675AF]">
        <div className="flex items-center gap-2 mb-4">
          <Calendar size={20} className="text-[#4675AF]" />
          <h2 className="text-lg font-bold text-[#05204B]">
            Período de Análise
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Data Inicial
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Data Final
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            />
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
          <p className="text-gray-600 text-sm font-medium">Total Entradas</p>
          <p className="text-2xl font-bold text-blue-500 mt-2">
            {pieLabelData[0].value.toLocaleString("pt-BR")}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
          <p className="text-gray-600 text-sm font-medium">Total Saídas</p>
          <p className="text-2xl font-bold text-orange-500 mt-2">
            {pieLabelData[1].value.toLocaleString("pt-BR")}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
          <p className="text-gray-600 text-sm font-medium">Saldo</p>
          <p className="text-2xl font-bold text-green-500 mt-2">
            {(pieLabelData[0].value - pieLabelData[1].value).toLocaleString(
              "pt-BR",
            )}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#4675AF]">
          <p className="text-gray-600 text-sm font-medium">
            Valor Total Estoque
          </p>
          <p className="text-2xl font-bold text-[#4675AF] mt-2">
            R${" "}
            {(reports?.totalStockValue || 0).toLocaleString("pt-BR", {
              maximumFractionDigits: 2,
            })}
          </p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Line Chart */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={20} className="text-[#4675AF]" />
            <h2 className="text-lg font-bold text-[#05204B]">
              Movimentações ao Longo do Tempo
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="entrada"
                stroke="#3b82f6"
                name="Entradas"
              />
              <Line
                type="monotone"
                dataKey="saida"
                stroke="#f97316"
                name="Saídas"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Bar Chart */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={20} className="text-[#4675AF]" />
            <h2 className="text-lg font-bold text-[#05204B]">
              Comparativo Diário
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="entrada" fill="#3b82f6" name="Entradas" />
              <Bar dataKey="saida" fill="#f97316" name="Saídas" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pie Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={20} className="text-[#4675AF]" />
            <h2 className="text-lg font-bold text-[#05204B]">
              Proporção Entradas vs Saídas
            </h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieLabelData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) =>
                  `${name}: ${value.toLocaleString("pt-BR")}`
                }
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {pieLabelData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Detailed Stats */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-bold text-[#05204B] mb-4">
            Estatísticas Detalhadas
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
              <span className="font-medium text-gray-700">
                Total de Movimentações
              </span>
              <span className="text-xl font-bold text-[#05204B]">
                {(pieLabelData[0].value + pieLabelData[1].value).toLocaleString(
                  "pt-BR",
                )}
              </span>
            </div>
            <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
              <span className="font-medium text-gray-700">
                Média de Entrada por Dia
              </span>
              <span className="text-xl font-bold text-[#4675AF]">
                {chartData.length > 0
                  ? Math.round(
                      (pieLabelData[0].value / chartData.length) * 10,
                    ) / 10
                  : 0}
              </span>
            </div>
            <div className="flex justify-between items-center p-4 bg-orange-50 rounded-lg">
              <span className="font-medium text-gray-700">
                Média de Saída por Dia
              </span>
              <span className="text-xl font-bold text-orange-500">
                {chartData.length > 0
                  ? Math.round(
                      (pieLabelData[1].value / chartData.length) * 10,
                    ) / 10
                  : 0}
              </span>
            </div>
            <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
              <span className="font-medium text-gray-700">
                Período Analisado
              </span>
              <span className="text-sm font-semibold text-gray-600">
                {new Date(startDate).toLocaleDateString("pt-BR")} a{" "}
                {new Date(endDate).toLocaleDateString("pt-BR")}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
