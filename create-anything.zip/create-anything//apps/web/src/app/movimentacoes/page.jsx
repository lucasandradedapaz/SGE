"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, TrendingUp, TrendingDown } from "lucide-react";
import { useState } from "react";

export default function Movimentacoes() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    product_id: "",
    type: "entrada",
    quantity: "",
    reason: "",
  });

  // Fetch products
  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const response = await fetch("/api/products");
      if (!response.ok) throw new Error("Erro ao buscar produtos");
      return response.json();
    },
  });

  // Fetch movements
  const { data: movements = [], isLoading } = useQuery({
    queryKey: ["movements", type, search],
    queryFn: async () => {
      let url = "/api/movements";
      const params = new URLSearchParams();
      if (type) params.append("type", type);
      if (params.toString()) url += "?" + params.toString();

      const response = await fetch(url);
      if (!response.ok) throw new Error("Erro ao buscar movimentações");
      let data = await response.json();

      if (search) {
        data = data.filter(
          (m) =>
            m.product_name.toLowerCase().includes(search.toLowerCase()) ||
            m.product_code.toLowerCase().includes(search.toLowerCase()),
        );
      }

      return data;
    },
  });

  // Create movement
  const createMutation = useMutation({
    mutationFn: async (data) => {
      const response = await fetch("/api/movements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Erro ao registrar movimentação");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["movements"] });
      queryClient.invalidateQueries({ queryKey: ["stock"] });
      queryClient.invalidateQueries({ queryKey: ["reports"] });
      setFormData({
        product_id: "",
        type: "entrada",
        quantity: "",
        reason: "",
      });
      setShowForm(false);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.product_id || !formData.quantity) {
      alert("Preencha os campos obrigatórios");
      return;
    }

    createMutation.mutate({
      product_id: parseInt(formData.product_id),
      type: formData.type,
      quantity: parseInt(formData.quantity),
      reason: formData.reason,
    });
  };

  const getTypeColor = (type) => {
    return type === "entrada"
      ? "bg-blue-100 text-blue-800"
      : "bg-orange-100 text-orange-800";
  };

  const getTypeIcon = (type) => {
    return type === "entrada" ? (
      <TrendingUp size={16} className="inline mr-1" />
    ) : (
      <TrendingDown size={16} className="inline mr-1" />
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-[#05204B]">Movimentações</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-[#05204B] text-[#FAFEFE] px-4 py-2 rounded-lg hover:bg-[#4675AF] transition-colors"
        >
          <Plus size={20} />
          Nova Movimentação
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-[#4675AF]">
          <h2 className="text-lg font-bold text-[#05204B] mb-4">
            Registrar Movimentação
          </h2>
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <select
              value={formData.product_id}
              onChange={(e) =>
                setFormData({ ...formData, product_id: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
            >
              <option value="">Selecione um produto</option>
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.code} - {product.name}
                </option>
              ))}
            </select>

            <select
              value={formData.type}
              onChange={(e) =>
                setFormData({ ...formData, type: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            >
              <option value="entrada">Entrada</option>
              <option value="saida">Saída</option>
            </select>

            <input
              type="number"
              placeholder="Quantidade"
              value={formData.quantity}
              onChange={(e) =>
                setFormData({ ...formData, quantity: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
              min="1"
            />

            <input
              type="text"
              placeholder="Motivo (opcional)"
              value={formData.reason}
              onChange={(e) =>
                setFormData({ ...formData, reason: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            />

            <div className="md:col-span-2 flex gap-2">
              <button
                type="submit"
                className="flex-1 bg-[#4675AF] text-[#FAFEFE] py-2 rounded-lg hover:bg-[#05204B] transition-colors font-semibold"
              >
                Registrar
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setFormData({
                    product_id: "",
                    type: "entrada",
                    quantity: "",
                    reason: "",
                  });
                }}
                className="flex-1 bg-gray-300 text-[#000000] py-2 rounded-lg hover:bg-gray-400 transition-colors font-semibold"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 flex-col md:flex-row">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Buscar produtos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
        </div>

        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
        >
          <option value="">Todas as movimentações</option>
          <option value="entrada">Entradas</option>
          <option value="saida">Saídas</option>
        </select>
      </div>

      {/* Movements Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4675AF] mx-auto"></div>
          </div>
        ) : movements.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            Nenhuma movimentação encontrada
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#05204B] text-[#FAFEFE]">
                  <th className="px-4 py-3 text-left font-semibold">Data</th>
                  <th className="px-4 py-3 text-left font-semibold">Código</th>
                  <th className="px-4 py-3 text-left font-semibold">Produto</th>
                  <th className="px-4 py-3 text-left font-semibold">Tipo</th>
                  <th className="px-4 py-3 text-left font-semibold">
                    Quantidade
                  </th>
                  <th className="px-4 py-3 text-left font-semibold">Motivo</th>
                </tr>
              </thead>
              <tbody>
                {movements.map((movement) => (
                  <tr
                    key={movement.id}
                    className="border-b hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      {new Date(movement.movement_date).toLocaleDateString(
                        "pt-BR",
                      )}
                    </td>
                    <td className="px-4 py-3">{movement.product_code}</td>
                    <td className="px-4 py-3">{movement.product_name}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${getTypeColor(movement.type)}`}
                      >
                        {getTypeIcon(movement.type)}
                        {movement.type === "entrada" ? "Entrada" : "Saída"}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-semibold">
                      {movement.quantity}
                    </td>
                    <td className="px-4 py-3">{movement.reason || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
