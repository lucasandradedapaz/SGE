"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Search } from "lucide-react";
import { useState } from "react";

export default function Estoque() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [quantities, setQuantities] = useState({});

  const { data: stock = [], isLoading } = useQuery({
    queryKey: ["stock", search],
    queryFn: async () => {
      const response = await fetch("/api/stock");
      if (!response.ok) throw new Error("Erro ao buscar estoque");
      let data = await response.json();
      if (search) {
        data = data.filter(
          (s) =>
            s.product_name.toLowerCase().includes(search.toLowerCase()) ||
            s.product_code.toLowerCase().includes(search.toLowerCase()),
        );
      }
      return data;
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      const response = await fetch("/api/stock", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Erro ao atualizar estoque");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stock"] });
      setEditingId(null);
      setQuantities({});
    },
  });

  const handleSave = (item) => {
    updateMutation.mutate({
      product_id: item.product_id,
      quantity: parseInt(quantities[item.id] || item.quantity),
    });
  };

  const getStockStatus = (item) => {
    if (item.quantity < item.min_quantity) {
      return {
        status: "crítico",
        color: "bg-red-100 text-red-800",
        icon: "🔴",
      };
    } else if (item.quantity < item.min_quantity * 1.5) {
      return {
        status: "baixo",
        color: "bg-yellow-100 text-yellow-800",
        icon: "🟡",
      };
    }
    return { status: "ok", color: "bg-green-100 text-green-800", icon: "🟢" };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-[#05204B]">Estoque</h1>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-red-500">
          <p className="text-gray-600 text-sm font-medium">Crítico</p>
          <p className="text-2xl font-bold text-red-500 mt-2">
            {stock.filter((s) => s.quantity < s.min_quantity).length}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
          <p className="text-gray-600 text-sm font-medium">Baixo</p>
          <p className="text-2xl font-bold text-yellow-500 mt-2">
            {
              stock.filter(
                (s) =>
                  s.quantity >= s.min_quantity &&
                  s.quantity < s.min_quantity * 1.5,
              ).length
            }
          </p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
          <p className="text-gray-600 text-sm font-medium">Normal</p>
          <p className="text-2xl font-bold text-green-500 mt-2">
            {stock.filter((s) => s.quantity >= s.min_quantity * 1.5).length}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Buscar produtos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
        </div>
      </div>

      {/* Stock Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4675AF] mx-auto"></div>
          </div>
        ) : stock.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            Nenhum produto encontrado
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#05204B] text-[#FAFEFE]">
                  <th className="px-4 py-3 text-left font-semibold">Código</th>
                  <th className="px-4 py-3 text-left font-semibold">Produto</th>
                  <th className="px-4 py-3 text-left font-semibold">
                    Quantidade Atual
                  </th>
                  <th className="px-4 py-3 text-left font-semibold">Mínimo</th>
                  <th className="px-4 py-3 text-left font-semibold">Status</th>
                  <th className="px-4 py-3 text-left font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody>
                {stock.map((item) => {
                  const status = getStockStatus(item);
                  const isEditing = editingId === item.id;

                  return (
                    <tr
                      key={item.id}
                      className="border-b hover:bg-gray-50 transition-colors"
                    >
                      <td className="px-4 py-3">{item.product_code}</td>
                      <td className="px-4 py-3">{item.product_name}</td>
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <input
                            type="number"
                            value={quantities[item.id] ?? item.quantity}
                            onChange={(e) =>
                              setQuantities({
                                ...quantities,
                                [item.id]: e.target.value,
                              })
                            }
                            className="px-2 py-1 border border-gray-300 rounded w-24"
                          />
                        ) : (
                          <span className="font-semibold">{item.quantity}</span>
                        )}
                      </td>
                      <td className="px-4 py-3">{item.min_quantity}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${status.color}`}
                        >
                          {status.icon} {status.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleSave(item)}
                              className="bg-[#4675AF] text-[#FAFEFE] px-3 py-1 rounded text-sm hover:bg-[#05204B]"
                            >
                              Salvar
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="bg-gray-300 text-[#000000] px-3 py-1 rounded text-sm hover:bg-gray-400"
                            >
                              Cancelar
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setEditingId(item.id);
                              setQuantities({
                                ...quantities,
                                [item.id]: item.quantity,
                              });
                            }}
                            className="text-[#4675AF] hover:text-[#05204B] transition-colors text-sm font-semibold"
                          >
                            Editar
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
