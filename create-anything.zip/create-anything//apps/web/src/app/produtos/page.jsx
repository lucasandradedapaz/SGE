"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit2, Trash2, Search } from "lucide-react";
import { useState } from "react";

export default function Produtos() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    description: "",
    category_id: "",
    price: "",
    min_quantity: "",
    unit: "un",
  });

  // Fetch products
  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products", search],
    queryFn: async () => {
      const url = new URL("/api/products", window.location.origin);
      if (search) url.searchParams.append("search", search);
      const response = await fetch(url);
      if (!response.ok) throw new Error("Erro ao buscar produtos");
      return response.json();
    },
  });

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Erro ao buscar categorias");
      return response.json();
    },
  });

  // Create/Update product
  const mutation = useMutation({
    mutationFn: async (data) => {
      if (editingId) {
        const response = await fetch(`/api/products/${editingId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        if (!response.ok) throw new Error("Erro ao atualizar produto");
        return response.json();
      } else {
        const response = await fetch("/api/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        if (!response.ok) throw new Error("Erro ao criar produto");
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setFormData({
        code: "",
        name: "",
        description: "",
        category_id: "",
        price: "",
        min_quantity: "",
        unit: "un",
      });
      setShowForm(false);
      setEditingId(null);
    },
  });

  // Delete product
  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Erro ao deletar produto");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate({
      ...formData,
      price: parseFloat(formData.price),
      min_quantity: parseInt(formData.min_quantity) || 0,
      category_id: formData.category_id ? parseInt(formData.category_id) : null,
    });
  };

  const handleEdit = (product) => {
    setFormData({
      code: product.code,
      name: product.name,
      description: product.description || "",
      category_id: product.category_id || "",
      price: product.price,
      min_quantity: product.min_quantity,
      unit: product.unit,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-[#05204B]">Produtos</h1>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditingId(null);
            if (showForm) {
              setFormData({
                code: "",
                name: "",
                description: "",
                category_id: "",
                price: "",
                min_quantity: "",
                unit: "un",
              });
            }
          }}
          className="flex items-center gap-2 bg-[#05204B] text-[#FAFEFE] px-4 py-2 rounded-lg hover:bg-[#4675AF] transition-colors"
        >
          <Plus size={20} />
          Novo Produto
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-[#4675AF]">
          <h2 className="text-lg font-bold text-[#05204B] mb-4">
            {editingId ? "Editar Produto" : "Novo Produto"}
          </h2>
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <input
              type="text"
              placeholder="Código"
              value={formData.code}
              onChange={(e) =>
                setFormData({ ...formData, code: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
            />
            <input
              type="text"
              placeholder="Nome"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
            />
            <input
              type="number"
              placeholder="Preço"
              value={formData.price}
              onChange={(e) =>
                setFormData({ ...formData, price: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
              step="0.01"
            />
            <input
              type="number"
              placeholder="Quantidade Mínima"
              value={formData.min_quantity}
              onChange={(e) =>
                setFormData({ ...formData, min_quantity: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            />
            <select
              value={formData.category_id}
              onChange={(e) =>
                setFormData({ ...formData, category_id: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            >
              <option value="">Selecione uma categoria</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
            <select
              value={formData.unit}
              onChange={(e) =>
                setFormData({ ...formData, unit: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
            >
              <option value="un">Unidade</option>
              <option value="kg">Quilograma</option>
              <option value="m">Metro</option>
              <option value="l">Litro</option>
              <option value="caixa">Caixa</option>
            </select>
            <textarea
              placeholder="Descrição"
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF] md:col-span-2"
              rows="3"
            />
            <div className="md:col-span-2 flex gap-2">
              <button
                type="submit"
                className="flex-1 bg-[#4675AF] text-[#FAFEFE] py-2 rounded-lg hover:bg-[#05204B] transition-colors font-semibold"
              >
                {editingId ? "Atualizar" : "Criar"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                  setFormData({
                    code: "",
                    name: "",
                    description: "",
                    category_id: "",
                    price: "",
                    min_quantity: "",
                    unit: "un",
                  });
                }}
                className="flex-1 bg-gray-300 text-[#000000] py-2 rounded-lg hover:bg-gray-400 transition-colors font-semibold"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Buscar produtos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4675AF] mx-auto"></div>
          </div>
        ) : products.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            Nenhum produto encontrado
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#05204B] text-[#FAFEFE]">
                  <th className="px-4 py-3 text-left font-semibold">Código</th>
                  <th className="px-4 py-3 text-left font-semibold">Nome</th>
                  <th className="px-4 py-3 text-left font-semibold">
                    Categoria
                  </th>
                  <th className="px-4 py-3 text-left font-semibold">Preço</th>
                  <th className="px-4 py-3 text-left font-semibold">Estoque</th>
                  <th className="px-4 py-3 text-left font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr
                    key={product.id}
                    className="border-b hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-4 py-3">{product.code}</td>
                    <td className="px-4 py-3">{product.name}</td>
                    <td className="px-4 py-3">
                      {product.category_name || "-"}
                    </td>
                    <td className="px-4 py-3">
                      R$ {parseFloat(product.price).toFixed(2)}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          product.stock_quantity >= product.min_quantity
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {product.stock_quantity || 0} {product.unit}
                      </span>
                    </td>
                    <td className="px-4 py-3 flex gap-2">
                      <button
                        onClick={() => handleEdit(product)}
                        className="text-[#4675AF] hover:text-[#05204B] transition-colors p-2 rounded hover:bg-gray-100"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm("Deseja deletar este produto?")) {
                            deleteMutation.mutate(product.id);
                          }
                        }}
                        className="text-red-500 hover:text-red-700 transition-colors p-2 rounded hover:bg-gray-100"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
