"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings, Plus, Trash2, Edit2 } from "lucide-react";
import { useState } from "react";

export default function Configuracoes() {
  const queryClient = useQueryClient();
  const [companyForm, setCompanyForm] = useState({
    name: "",
    email: "",
    phone: "",
    cnpj: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
  });
  const [categoryForm, setCategoryForm] = useState({
    name: "",
    description: "",
  });
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState(null);

  // Fetch company data
  const { data: company } = useQuery({
    queryKey: ["company"],
    queryFn: async () => {
      const response = await fetch("/api/company");
      if (!response.ok) throw new Error("Erro ao buscar dados da empresa");
      return response.json();
    },
    onSuccess: (data) => {
      if (data) {
        setCompanyForm(data);
      }
    },
  });

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Erro ao buscar categorias");
      return response.json();
    },
  });

  // Update company
  const updateCompanyMutation = useMutation({
    mutationFn: async (data) => {
      const response = await fetch("/api/company", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Erro ao atualizar dados da empresa");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company"] });
      alert("Dados da empresa atualizados com sucesso!");
    },
  });

  // Create category
  const createCategoryMutation = useMutation({
    mutationFn: async (data) => {
      const response = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Erro ao criar categoria");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["categories"] });
      setCategoryForm({ name: "", description: "" });
      setShowCategoryForm(false);
      alert("Categoria criada com sucesso!");
    },
  });

  // Delete category
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id) => {
      // Since we don't have a delete endpoint, we'll just notify
      alert("Funcionalidade não disponível nesta versão");
    },
  });

  const handleCompanySubmit = (e) => {
    e.preventDefault();
    updateCompanyMutation.mutate(companyForm);
  };

  const handleCategorySubmit = (e) => {
    e.preventDefault();
    if (!categoryForm.name) {
      alert("Nome da categoria é obrigatório");
      return;
    }
    createCategoryMutation.mutate(categoryForm);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-[#05204B]">Configurações</h1>
        <p className="text-gray-600 mt-2">
          Gerencie os dados da sua empresa e categorias
        </p>
      </div>

      {/* Company Data */}
      <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-[#4675AF]">
        <div className="flex items-center gap-2 mb-6">
          <Settings size={24} className="text-[#4675AF]" />
          <h2 className="text-2xl font-bold text-[#05204B]">
            Dados da Empresa
          </h2>
        </div>

        <form
          onSubmit={handleCompanySubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <input
            type="text"
            placeholder="Nome da Empresa"
            value={companyForm.name || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, name: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="email"
            placeholder="Email"
            value={companyForm.email || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, email: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="tel"
            placeholder="Telefone"
            value={companyForm.phone || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, phone: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="text"
            placeholder="CNPJ"
            value={companyForm.cnpj || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, cnpj: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="text"
            placeholder="Endereço"
            value={companyForm.address || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, address: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="text"
            placeholder="Cidade"
            value={companyForm.city || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, city: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="text"
            placeholder="Estado"
            value={companyForm.state || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, state: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />
          <input
            type="text"
            placeholder="CEP"
            value={companyForm.zip_code || ""}
            onChange={(e) =>
              setCompanyForm({ ...companyForm, zip_code: e.target.value })
            }
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
          />

          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full bg-[#4675AF] text-[#FAFEFE] py-2 rounded-lg hover:bg-[#05204B] transition-colors font-semibold"
            >
              Salvar Dados da Empresa
            </button>
          </div>
        </form>
      </div>

      {/* Categories */}
      <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-[#4675AF]">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#05204B]">Categorias</h2>
          <button
            onClick={() => {
              setShowCategoryForm(!showCategoryForm);
              setEditingCategoryId(null);
              setCategoryForm({ name: "", description: "" });
            }}
            className="flex items-center gap-2 bg-[#05204B] text-[#FAFEFE] px-4 py-2 rounded-lg hover:bg-[#4675AF] transition-colors"
          >
            <Plus size={20} />
            Nova Categoria
          </button>
        </div>

        {/* Add/Edit Category Form */}
        {showCategoryForm && (
          <form
            onSubmit={handleCategorySubmit}
            className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded-lg"
          >
            <input
              type="text"
              placeholder="Nome da Categoria"
              value={categoryForm.name}
              onChange={(e) =>
                setCategoryForm({ ...categoryForm, name: e.target.value })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF]"
              required
            />
            <textarea
              placeholder="Descrição (opcional)"
              value={categoryForm.description}
              onChange={(e) =>
                setCategoryForm({
                  ...categoryForm,
                  description: e.target.value,
                })
              }
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#4675AF] md:col-span-2"
              rows="3"
            />
            <div className="md:col-span-2 flex gap-2">
              <button
                type="submit"
                className="flex-1 bg-[#4675AF] text-[#FAFEFE] py-2 rounded-lg hover:bg-[#05204B] transition-colors font-semibold"
              >
                {editingCategoryId ? "Atualizar" : "Criar"} Categoria
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowCategoryForm(false);
                  setEditingCategoryId(null);
                  setCategoryForm({ name: "", description: "" });
                }}
                className="flex-1 bg-gray-300 text-[#000000] py-2 rounded-lg hover:bg-gray-400 transition-colors font-semibold"
              >
                Cancelar
              </button>
            </div>
          </form>
        )}

        {/* Categories List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories.map((category) => (
            <div
              key={category.id}
              className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-bold text-[#05204B]">{category.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {category.description || "Sem descrição"}
                  </p>
                  <p className="text-xs text-gray-400 mt-2">
                    Criada em:{" "}
                    {new Date(category.created_at).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => {
                      setCategoryForm(category);
                      setEditingCategoryId(category.id);
                      setShowCategoryForm(true);
                    }}
                    className="text-[#4675AF] hover:text-[#05204B] transition-colors p-2 rounded hover:bg-gray-100"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("Deseja deletar esta categoria?")) {
                        deleteCategoryMutation.mutate(category.id);
                      }
                    }}
                    className="text-red-500 hover:text-red-700 transition-colors p-2 rounded hover:bg-gray-100"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {categories.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            Nenhuma categoria criada ainda
          </div>
        )}
      </div>

      {/* System Info */}
      <div className="bg-white rounded-lg shadow-md p-6 border-t-4 border-gray-300">
        <h2 className="text-2xl font-bold text-[#05204B] mb-4">
          Informações do Sistema
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">Versão</p>
            <p className="text-xl font-bold text-[#05204B]">1.0.0</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">Última Atualização</p>
            <p className="text-xl font-bold text-[#05204B]">
              {new Date().toLocaleDateString("pt-BR")}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">Banco de Dados</p>
            <p className="text-xl font-bold text-[#4675AF]">PostgreSQL</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">Status</p>
            <p className="text-xl font-bold text-green-500">✓ Online</p>
          </div>
        </div>
      </div>
    </div>
  );
}
