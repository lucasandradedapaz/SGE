import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const product = await sql`
      SELECT p.id, p.code, p.name, p.description, p.category_id, p.price, 
             p.min_quantity, p.unit, p.image_url, c.name as category_name,
             s.quantity as stock_quantity
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN stock s ON p.id = s.product_id
      WHERE p.id = ${id}
    `;

    if (!product.length) {
      return Response.json(
        { error: "Produto não encontrado" },
        { status: 404 },
      );
    }

    return Response.json(product[0]);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Erro ao buscar produto" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const {
      code,
      name,
      description,
      category_id,
      price,
      min_quantity,
      unit,
      image_url,
    } = body;

    const setClauses = [];
    const values = [];
    let paramCount = 1;

    if (code !== undefined) {
      setClauses.push(`code = $${paramCount}`);
      values.push(code);
      paramCount++;
    }
    if (name !== undefined) {
      setClauses.push(`name = $${paramCount}`);
      values.push(name);
      paramCount++;
    }
    if (description !== undefined) {
      setClauses.push(`description = $${paramCount}`);
      values.push(description);
      paramCount++;
    }
    if (category_id !== undefined) {
      setClauses.push(`category_id = $${paramCount}`);
      values.push(category_id);
      paramCount++;
    }
    if (price !== undefined) {
      setClauses.push(`price = $${paramCount}`);
      values.push(price);
      paramCount++;
    }
    if (min_quantity !== undefined) {
      setClauses.push(`min_quantity = $${paramCount}`);
      values.push(min_quantity);
      paramCount++;
    }
    if (unit !== undefined) {
      setClauses.push(`unit = $${paramCount}`);
      values.push(unit);
      paramCount++;
    }
    if (image_url !== undefined) {
      setClauses.push(`image_url = $${paramCount}`);
      values.push(image_url);
      paramCount++;
    }

    if (setClauses.length === 0) {
      return Response.json(
        { error: "Nenhum campo para atualizar" },
        { status: 400 },
      );
    }

    setClauses.push(`updated_at = $${paramCount}`);
    values.push(new Date());
    values.push(id);

    const query = `UPDATE products SET ${setClauses.join(", ")} WHERE id = $${paramCount + 1} RETURNING id`;
    const result = await sql(query, values);

    if (!result.length) {
      return Response.json(
        { error: "Produto não encontrado" },
        { status: 404 },
      );
    }

    return Response.json({
      id: result[0].id,
      message: "Produto atualizado com sucesso",
    });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao atualizar produto" },
      { status: 500 },
    );
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    // Delete related stock and movements
    await sql`DELETE FROM stock WHERE product_id = ${id}`;
    await sql`DELETE FROM movements WHERE product_id = ${id}`;
    const result =
      await sql`DELETE FROM products WHERE id = ${id} RETURNING id`;

    if (!result.length) {
      return Response.json(
        { error: "Produto não encontrado" },
        { status: 404 },
      );
    }

    return Response.json({ message: "Produto deletado com sucesso" });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Erro ao deletar produto" }, { status: 500 });
  }
}
