import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");
    const categoryId = searchParams.get("categoryId");

    let query = `
      SELECT p.id, p.code, p.name, p.description, p.category_id, p.price, 
             p.min_quantity, p.unit, p.image_url, c.name as category_name,
             s.quantity as stock_quantity
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN stock s ON p.id = s.product_id
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (LOWER(p.name) LIKE LOWER($${params.length + 1}) OR LOWER(p.code) LIKE LOWER($${params.length + 1}))`;
      params.push(`%${search}%`);
    }

    if (categoryId) {
      query += ` AND p.category_id = $${params.length + 1}`;
      params.push(parseInt(categoryId));
    }

    query += ` ORDER BY p.name ASC`;

    const products = await sql(query, params);
    return Response.json(products);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Erro ao buscar produtos" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      code,
      name,
      description,
      category_id,
      price,
      min_quantity,
      unit,
      image_url,
    } = body;

    if (!code || !name || !price) {
      return Response.json(
        { error: "Campos obrigatórios faltando" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO products (code, name, description, category_id, price, min_quantity, unit, image_url)
      VALUES (${code}, ${name}, ${description}, ${category_id}, ${price}, ${min_quantity || 0}, ${unit || "un"}, ${image_url})
      RETURNING id
    `;

    const productId = result[0].id;

    // Create stock entry
    await sql`
      INSERT INTO stock (product_id, quantity)
      VALUES (${productId}, 0)
    `;

    return Response.json({
      id: productId,
      message: "Produto criado com sucesso",
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Erro ao criar produto" }, { status: 500 });
  }
}
