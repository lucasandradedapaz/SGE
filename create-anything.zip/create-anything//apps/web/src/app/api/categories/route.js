import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const categories = await sql`
      SELECT id, name, description, created_at
      FROM categories
      ORDER BY name ASC
    `;
    return Response.json(categories);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao buscar categorias" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { name, description } = body;

    if (!name) {
      return Response.json(
        { error: "Nome da categoria é obrigatório" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO categories (name, description)
      VALUES (${name}, ${description})
      RETURNING id
    `;

    return Response.json({
      id: result[0].id,
      message: "Categoria criada com sucesso",
    });
  } catch (error) {
    console.error(error);
    if (error.message.includes("unique")) {
      return Response.json({ error: "Categoria já existe" }, { status: 400 });
    }
    return Response.json({ error: "Erro ao criar categoria" }, { status: 500 });
  }
}
