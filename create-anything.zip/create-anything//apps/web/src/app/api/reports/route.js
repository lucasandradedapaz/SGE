import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    // Total products
    const totalProducts = await sql`SELECT COUNT(*) as count FROM products`;

    // Total stock value
    const totalStockValue = await sql`
      SELECT SUM(s.quantity * p.price) as total
      FROM stock s
      LEFT JOIN products p ON s.product_id = p.id
    `;

    // Products below minimum
    const productsBelow = await sql`
      SELECT COUNT(*) as count
      FROM stock s
      LEFT JOIN products p ON s.product_id = p.id
      WHERE s.quantity < p.min_quantity
    `;

    // Today movements
    const today = new Date().toISOString().split("T")[0];
    const enteredToday = await sql`
      SELECT COUNT(*) as count, COALESCE(SUM(quantity), 0) as total
      FROM movements
      WHERE type = 'entrada' AND DATE(movement_date) = ${today}
    `;

    const exitedToday = await sql`
      SELECT COUNT(*) as count, COALESCE(SUM(quantity), 0) as total
      FROM movements
      WHERE type = 'saida' AND DATE(movement_date) = ${today}
    `;

    // Monthly chart data
    let chartQuery = `
      SELECT DATE_TRUNC('day', movement_date) as date, type, SUM(quantity) as total
      FROM movements
      WHERE 1=1
    `;
    const chartParams = [];

    if (startDate) {
      chartQuery += ` AND movement_date >= $${chartParams.length + 1}`;
      chartParams.push(new Date(startDate));
    }

    if (endDate) {
      chartQuery += ` AND movement_date <= $${chartParams.length + 1}`;
      chartParams.push(new Date(endDate));
    }

    chartQuery += ` GROUP BY DATE_TRUNC('day', movement_date), type ORDER BY date DESC`;

    const chartData = await sql(chartQuery, chartParams);

    return Response.json({
      totalProducts: totalProducts[0].count,
      totalStockValue: totalStockValue[0].total || 0,
      productsBelow: productsBelow[0].count,
      enteredToday: enteredToday[0].total,
      exitedToday: exitedToday[0].total,
      chartData: chartData,
    });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao buscar relatórios" },
      { status: 500 },
    );
  }
}
