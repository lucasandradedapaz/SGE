import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const stock = await sql`
      SELECT s.id, s.product_id, s.quantity, s.last_updated,
             p.name as product_name, p.code as product_code, p.price, p.min_quantity
      FROM stock s
      LEFT JOIN products p ON s.product_id = p.id
      ORDER BY p.name ASC
    `;
    return Response.json(stock);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Erro ao buscar estoque" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const body = await request.json();
    const { product_id, quantity } = body;

    if (!product_id || quantity === undefined) {
      return Response.json(
        { error: "Campos obrigatórios faltando" },
        { status: 400 },
      );
    }

    const result = await sql`
      UPDATE stock
      SET quantity = ${quantity}, last_updated = NOW()
      WHERE product_id = ${product_id}
      RETURNING id
    `;

    if (!result.length) {
      return Response.json(
        { error: "Estoque não encontrado" },
        { status: 404 },
      );
    }

    return Response.json({ message: "Estoque atualizado com sucesso" });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao atualizar estoque" },
      { status: 500 },
    );
  }
}
