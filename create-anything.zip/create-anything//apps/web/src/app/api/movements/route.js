import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");
    const limit = searchParams.get("limit") || 100;

    let query = `
      SELECT m.id, m.product_id, m.type, m.quantity, m.reason, m.movement_date,
             p.name as product_name, p.code as product_code
      FROM movements m
      LEFT JOIN products p ON m.product_id = p.id
      WHERE 1=1
    `;
    const params = [];

    if (type) {
      query += ` AND m.type = $${params.length + 1}`;
      params.push(type);
    }

    if (startDate) {
      query += ` AND m.movement_date >= $${params.length + 1}`;
      params.push(new Date(startDate));
    }

    if (endDate) {
      query += ` AND m.movement_date <= $${params.length + 1}`;
      params.push(new Date(endDate));
    }

    query += ` ORDER BY m.movement_date DESC LIMIT $${params.length + 1}`;
    params.push(parseInt(limit));

    const movements = await sql(query, params);
    return Response.json(movements);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao buscar movimentações" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { product_id, type, quantity, reason } = body;

    if (!product_id || !type || !quantity) {
      return Response.json(
        { error: "Campos obrigatórios faltando" },
        { status: 400 },
      );
    }

    if (!["entrada", "saida"].includes(type)) {
      return Response.json({ error: "Tipo inválido" }, { status: 400 });
    }

    // Create movement
    const movement = await sql`
      INSERT INTO movements (product_id, type, quantity, reason)
      VALUES (${product_id}, ${type}, ${quantity}, ${reason})
      RETURNING id
    `;

    // Update stock
    if (type === "entrada") {
      await sql`
        UPDATE stock
        SET quantity = quantity + ${quantity}, last_updated = NOW()
        WHERE product_id = ${product_id}
      `;
    } else if (type === "saida") {
      await sql`
        UPDATE stock
        SET quantity = quantity - ${quantity}, last_updated = NOW()
        WHERE product_id = ${product_id}
      `;
    }

    return Response.json({
      id: movement[0].id,
      message: "Movimentação registrada com sucesso",
    });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao registrar movimentação" },
      { status: 500 },
    );
  }
}
