import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const company = await sql`
      SELECT * FROM company_data
      WHERE id = 1
    `;

    if (!company.length) {
      return Response.json(null);
    }

    return Response.json(company[0]);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao buscar dados da empresa" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { name, email, phone, cnpj, address, city, state, zip_code } = body;

    const existing = await sql`SELECT id FROM company_data WHERE id = 1`;

    if (existing.length) {
      await sql`
        UPDATE company_data
        SET name = ${name}, email = ${email}, phone = ${phone}, cnpj = ${cnpj},
            address = ${address}, city = ${city}, state = ${state}, zip_code = ${zip_code},
            updated_at = NOW()
        WHERE id = 1
      `;
    } else {
      await sql`
        INSERT INTO company_data (id, name, email, phone, cnpj, address, city, state, zip_code)
        VALUES (1, ${name}, ${email}, ${phone}, ${cnpj}, ${address}, ${city}, ${state}, ${zip_code})
      `;
    }

    return Response.json({
      message: "Dados da empresa atualizados com sucesso",
    });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Erro ao atualizar dados da empresa" },
      { status: 500 },
    );
  }
}
