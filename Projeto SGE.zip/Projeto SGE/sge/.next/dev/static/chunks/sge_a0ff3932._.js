(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2b327c21._.js",
  "static/chunks/19111_next_dist_compiled_react-dom_fc9cf688._.js",
  "static/chunks/19111_next_dist_compiled_react-server-dom-turbopack_7cef0ef2._.js",
  "static/chunks/19111_next_dist_compiled_next-devtools_index_24b24bd8.js",
  "static/chunks/19111_next_dist_compiled_20c0540c._.js",
  "static/chunks/19111_next_dist_client_8ca0a4d8._.js",
  "static/chunks/19111_next_dist_d2855098._.js",
  "static/chunks/19111_@swc_helpers_cjs_92b2acfa._.js"
],
    source: "entry"
});
