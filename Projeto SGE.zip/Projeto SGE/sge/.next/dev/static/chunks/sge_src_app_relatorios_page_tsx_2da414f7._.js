(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/19111_recharts_es6_util_7046b795._.js",
  "static/chunks/19111_recharts_es6_state_b6d9b1dd._.js",
  "static/chunks/19111_recharts_es6_component_7774175c._.js",
  "static/chunks/19111_recharts_es6_cartesian_60ec38af._.js",
  "static/chunks/19111_recharts_es6_579fcd28._.js",
  "static/chunks/19111_65c13414._.js",
  "static/chunks/sge_src_app_relatorios_page_tsx_31bca914._.js"
],
    source: "dynamic"
});
