(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/sge_src_app_login_page_tsx_5b8f0c7c._.js"
],
    source: "dynamic"
});
