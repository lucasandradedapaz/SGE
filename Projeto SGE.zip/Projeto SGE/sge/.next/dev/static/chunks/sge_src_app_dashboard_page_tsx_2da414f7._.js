(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/19111_6f376305._.js",
  "static/chunks/sge_src_app_dashboard_page_tsx_30c8fe75._.js"
],
    source: "dynamic"
});
