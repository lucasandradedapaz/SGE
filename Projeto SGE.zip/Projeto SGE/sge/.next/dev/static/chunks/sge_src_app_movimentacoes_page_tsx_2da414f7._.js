(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/19111_ed75900d._.js",
  "static/chunks/sge_src_app_movimentacoes_page_tsx_5a975e77._.js"
],
    source: "dynamic"
});
