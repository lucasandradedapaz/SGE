globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/19111_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2b327c21._.js",
    "static/chunks/19111_next_dist_compiled_react-dom_fc9cf688._.js",
    "static/chunks/19111_next_dist_compiled_react-server-dom-turbopack_7cef0ef2._.js",
    "static/chunks/19111_next_dist_compiled_next-devtools_index_24b24bd8.js",
    "static/chunks/19111_next_dist_compiled_20c0540c._.js",
    "static/chunks/19111_next_dist_client_8ca0a4d8._.js",
    "static/chunks/19111_next_dist_d2855098._.js",
    "static/chunks/19111_@swc_helpers_cjs_92b2acfa._.js",
    "static/chunks/sge_a0ff3932._.js",
    "static/chunks/turbopack-sge_9d234572._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];