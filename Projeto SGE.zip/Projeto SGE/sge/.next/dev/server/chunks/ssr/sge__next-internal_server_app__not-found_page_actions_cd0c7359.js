module.exports = [
"[project]/sge/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app__not-found_page_actions_cd0c7359.js.map