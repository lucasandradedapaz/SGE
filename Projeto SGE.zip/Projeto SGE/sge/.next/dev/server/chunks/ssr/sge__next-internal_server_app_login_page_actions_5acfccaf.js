module.exports = [
"[project]/sge/.next-internal/server/app/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_login_page_actions_5acfccaf.js.map