module.exports = [
"[project]/sge/.next-internal/server/app/estoque/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_estoque_page_actions_f95a29b6.js.map