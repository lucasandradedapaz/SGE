module.exports = [
"[project]/sge/.next-internal/server/app/produtos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_produtos_page_actions_3af21366.js.map