module.exports = [
"[project]/sge/.next-internal/server/app/configuracoes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_configuracoes_page_actions_90baddcf.js.map