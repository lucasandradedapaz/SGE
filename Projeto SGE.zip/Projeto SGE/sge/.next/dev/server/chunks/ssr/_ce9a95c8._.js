module.exports = [
"[project]/src/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const { jsxDEV: _jsxDEV } = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
{}/*#__PURE__*/ _jsxDEV("div", {
    className: "w-64 flex flex-col",
    style: {
        backgroundColor: '#05204B'
    },
    children: [
        /*#__PURE__*/ _jsxDEV("div", {
            className: "p-6 border-b border-[#0f2a56]",
            children: [
                /*#__PURE__*/ _jsxDEV("h1", {
                    className: "text-3xl font-bold",
                    style: {
                        color: '#000000'
                    },
                    children: "SGE"
                }, void 0, false, {
                    fileName: "[project]/src/app/layout.tsx",
                    lineNumber: 4,
                    columnNumber: 5
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("p", {
                    className: "text-sm",
                    style: {
                        color: '#000000',
                        opacity: 0.8
                    },
                    children: "Sistema de Gestão de Estoque"
                }, void 0, false, {
                    fileName: "[project]/src/app/layout.tsx",
                    lineNumber: 5,
                    columnNumber: 5
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/layout.tsx",
            lineNumber: 3,
            columnNumber: 3
        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
        /*#__PURE__*/ _jsxDEV("nav", {
            className: "flex-1 p-4",
            children: navItems.map((item)=>{
                const Icon = item.icon;
                const isActive = pathname.startsWith(item.href);
                return /*#__PURE__*/ _jsxDEV(Link, {
                    href: item.href,
                    className: `flex items-center gap-3 px-5 py-4 rounded-xl mb-2 transition-all font-semibold ${isActive ? 'bg-[#4675AF] text-white shadow-lg' : 'text-black hover:bg-[#4675AF]/20 hover:text-[#000000]'}`,
                    children: [
                        /*#__PURE__*/ _jsxDEV(Icon, {
                            size: 22,
                            style: {
                                color: isActive ? 'white' : '#000000'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/app/layout.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("span", {
                            children: item.name
                        }, void 0, false, {
                            fileName: "[project]/src/app/layout.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, item.name, true, {
                    fileName: "[project]/src/app/layout.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e);
            })
        }, void 0, false, {
            fileName: "[project]/src/app/layout.tsx",
            lineNumber: 8,
            columnNumber: 3
        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
        /*#__PURE__*/ _jsxDEV("div", {
            className: "p-4 border-t border-[#0f2a56]",
            children: [
                /*#__PURE__*/ _jsxDEV("button", {
                    onClick: handleLogout,
                    className: "flex items-center gap-3 px-5 py-4 rounded-xl text-black hover:bg-[#4675AF]/20 hover:text-[#000000] w-full text-left font-medium transition-all",
                    children: [
                        /*#__PURE__*/ _jsxDEV(LogOut, {
                            size: 22
                        }, void 0, false, {
                            fileName: "[project]/src/app/layout.tsx",
                            lineNumber: 34,
                            columnNumber: 7
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("span", {
                            children: "Sair"
                        }, void 0, false, {
                            fileName: "[project]/src/app/layout.tsx",
                            lineNumber: 35,
                            columnNumber: 7
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/layout.tsx",
                    lineNumber: 30,
                    columnNumber: 5
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                /*#__PURE__*/ _jsxDEV("p", {
                    className: "text-xs text-center mt-6",
                    style: {
                        color: '#000000',
                        opacity: 0.7
                    },
                    children: "SGE v1.0"
                }, void 0, false, {
                    fileName: "[project]/src/app/layout.tsx",
                    lineNumber: 37,
                    columnNumber: 5
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/layout.tsx",
            lineNumber: 29,
            columnNumber: 3
        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
    ]
}, void 0, true, {
    fileName: "[project]/src/app/layout.tsx",
    lineNumber: 2,
    columnNumber: 1
}, /*TURBOPACK member replacement*/ __turbopack_context__.e);
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=_ce9a95c8._.js.map