module.exports = [
"[project]/sge/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_page_actions_832171d2.js.map