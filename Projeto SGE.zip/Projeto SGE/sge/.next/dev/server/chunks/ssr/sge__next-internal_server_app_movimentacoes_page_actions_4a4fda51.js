module.exports = [
"[project]/sge/.next-internal/server/app/movimentacoes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sge__next-internal_server_app_movimentacoes_page_actions_4a4fda51.js.map