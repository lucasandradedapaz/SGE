import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: 'class', // <-- ESSA LINHA MATA O DARK MODE AUTOMÁTICO
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#FAFEFE",
        sidebar: "#05204B",
        primary: "#4675AF",
        "primary-hover": "#3d66a0",
        "primary-light": "#5a8cc4",
        muted: "#64748b",
        success: "#10b981",
        warning: "#f59e0b",
        danger: "#ef4444",
        card: "#ffffff",
      },
    },
  },
  plugins: [],
};

export default config;