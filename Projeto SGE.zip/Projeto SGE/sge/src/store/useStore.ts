import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Product {
  id: string;
  codigo: string;
  nome: string;
  categoria: string;
  quantidade: number;
  estoque_minimo: number;
  preco_custo: number;
  preco_venda: number;
}

interface Movement {
  id: string;
  produtoId: string;
  tipo: 'entrada' | 'saida';
  quantidade: number;
  data: string;
  produtoNome?: string;
}

interface Company {
  nome: string;
  email: string;
  telefone: string;
  cnpj: string;
  endereco: string;
  cidade: string;
  estado: string;
  cep: string;
}

interface Store {
  products: Product[];
  movements: Movement[];
  company: Company;
  isLoggedIn: boolean;

  login: () => void;
  logout: () => void;

  addProduct: (p: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, p: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  addMovement: (m: Omit<Movement, 'id' | 'data' | 'produtoNome'> & { produtoNome: string }) => void;

  updateCompany: (c: Partial<Company>) => void;
}

export const useStore = create<Store>()(
  persist(
    (set) => ({
      products: [],
      movements: [],
      company: {
        nome: "Minha Empresa",
        email: "",
        telefone: "",
        cnpj: "",
        endereco: "",
        cidade: "",
        estado: "",
        cep: "",
      },
      isLoggedIn: false,

      login: () => set({ isLoggedIn: true }),
      logout: () => set({ isLoggedIn: false }),

      addProduct: (p) =>
        set((state) => ({
          products: [...state.products, { ...p, id: Date.now().toString() }],
        })),

      updateProduct: (id, updates) =>
        set((state) => ({
          products: state.products.map((p) => (p.id === id ? { ...p, ...updates } : p)),
        })),

      deleteProduct: (id) =>
        set((state) => ({
          products: state.products.filter((p) => p.id !== id),
        })),

      addMovement: (m) =>
        set((state) => ({
          movements: [
            ...state.movements,
            {
              ...m,
              id: Date.now().toString(),
              data: new Date().toISOString(),
            },
          ],
          products: state.products.map((p) =>
            p.id === m.produtoId
              ? {
                  ...p,
                  quantidade:
                    m.tipo === 'entrada'
                      ? p.quantidade + m.quantidade
                      : p.quantidade - m.quantidade,
                }
              : p
          ),
        })),

      updateCompany: (updates) =>
        set((state) => ({
          company: { ...state.company, ...updates },
        })),
    }),
    {
      name: 'sge-storage',
    }
  )
);