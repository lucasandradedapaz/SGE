'use client';

import { useStore } from '@/store/useStore';
import { ArrowUp, ArrowDown, Search } from 'lucide-react';
import { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function MovimentacoesPage() {
  const { movements } = useStore();
  const [busca, setBusca] = useState('');
  const [filtroTipo, setFiltroTipo] = useState<'todos' | 'entrada' | 'saida'>('todos');

  const movimentacoesFiltradas = movements
    .filter(m => 
      m.produtoNome.toLowerCase().includes(busca.toLowerCase()) &&
      (filtroTipo === 'todos' || m.tipo === filtroTipo)
    )
    .reverse();

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      <div className="mb-10">
        <h1 style={{ color: '#000000' }} className="text-4xl font-bold">Movimentações</h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">Histórico completo de entradas e saídas</p>
      </div>

      <div className="bg-white rounded-3xl shadow-lg p-6 mb-8 border border-gray-100">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-4 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por produto..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none text-lg"
              style={{ color: '#000000' }}
            />
          </div>
          <select
            value={filtroTipo}
            onChange={(e) => setFiltroTipo(e.target.value as any)}
            className="px-8 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] font-semibold"
            style={{ color: '#000000' }}
          >
            <option value="todos">Todas as movimentações</option>
            <option value="entrada">Apenas entradas</option>
            <option value="saida">Apenas saídas</option>
          </select>
          <button className="bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold px-8 py-4 rounded-2xl shadow-lg transition">
            + Nova Movimentação
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
        {movimentacoesFiltradas.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-2xl text-gray-500">Nenhuma movimentação encontrada</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {movimentacoesFiltradas.map((m) => (
              <div key={m.id} className="p-8 hover:bg-gray-50 transition">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                      m.tipo === 'entrada' ? 'bg-green-500' : 'bg-red-500'
                    }`}>
                      {m.tipo === 'entrada' ? 
                        <ArrowUp size={32} className="text-white" /> : 
                        <ArrowDown size={32} className="text-white" />
                      }
                    </div>
                    <div>
                      <p className="text-2xl font-bold" style={{ color: '#000000' }}>{m.produtoNome}</p>
                      <p className="text-gray-600 text-lg">
                        {format(new Date(m.data), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-4xl font-bold ${m.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                      {m.tipo === 'entrada' ? '+' : '-'}{m.quantidade}
                    </p>
                    <p className="text-gray-600 font-semibold">{m.tipo.toUpperCase()}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}