'use client';

import { useStore } from '@/store/useStore';
import { Building2, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';

export default function ConfiguracoesPage() {
  const { company, updateCompany } = useStore();
  const [form, setForm] = useState(company);
  const [novaCategoria, setNovaCategoria] = useState('');

  const categorias = [...new Set(useStore.getState().products.map(p => p.categoria).filter(Boolean))];

  const handleSave = () => {
    updateCompany(form);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      <div className="mb-10">
        <h1 style={{ color: '#000000' }} className="text-4xl font-bold">Configurações</h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">Gerencie os dados da sua empresa e categorias</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Dados da Empresa */}
        <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 rounded-2xl bg-[#4675AF] flex items-center justify-center">
              <Building2 size={32} className="text-white" />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: '#000000' }}>Dados da Empresa</h2>
          </div>

          <div className="space-y-6">
            <input placeholder="Nome da Empresa" value={form.nome} onChange={(e) => setForm({...form, nome: e.target.value})} className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
            <input placeholder="Email" value={form.email} onChange={(e) => setForm({...form, email: e.target.value})} className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
            <input placeholder="Telefone" value={form.telefone} onChange={(e) => setForm({...form, telefone: e.target.value})} className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
            <input placeholder="CNPJ" value={form.cnpj} onChange={(e) => setForm({...form, cnpj: e.target.value})} className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
            <div className="grid grid-cols-2 gap-4">
              <input placeholder="Cidade" value={form.cidade} onChange={(e) => setForm({...form, cidade: e.target.value})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
              <input placeholder="Estado" value={form.estado} onChange={(e) => setForm({...form, estado: e.target.value})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
            </div>
            <button onClick={handleSave} className="w-full bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold py-5 rounded-2xl shadow-lg transition text-xl">
              Salvar Dados da Empresa
            </button>
          </div>
        </div>

        {/* Categorias */}
        <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100">
          <h2 className="text-3xl font-bold mb-8" style={{ color: '#000000' }}>Categorias</h2>
          
          <div className="flex gap-4 mb-8">
            <input 
              placeholder="Nova categoria" 
              value={novaCategoria} 
              onChange={(e) => setNovaCategoria(e.target.value)}
              className="flex-1 px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg"
              style={{ color: '#000000' }}
            />
            <button className="bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold px-8 py-4 rounded-2xl shadow-lg transition flex items-center gap-3">
              <Plus size={24} />
              Adicionar
            </button>
          </div>

          <div className="space-y-4">
            {categorias.length === 0 ? (
              <p className="text-center text-gray-500 py-12 text-xl">Nenhuma categoria criada ainda</p>
            ) : (
              categorias.map(cat => (
                <div key={cat} className="flex items-center justify-between p-6 rounded-2xl border border-gray-200 hover:shadow-md transition">
                  <p className="text-2xl font-semibold" style={{ color: '#000000' }}>{cat}</p>
                  <button className="p-4 rounded-xl bg-red-100 hover:bg-red-200 transition">
                    <Trash2 size={24} className="text-red-600" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="mt-12 text-center text-gray-500">
        <p>SGE v1.0 • © 2025 {company.nome || 'Sua Empresa'}</p>
      </div>
    </div>
  );
}