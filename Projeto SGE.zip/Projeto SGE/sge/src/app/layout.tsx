import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Layout from "@/components/Layout";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "SGE - Sistema de Gestão de Estoque",
  description: "Controle total do seu estoque",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-br" className="light">  {/* <-- AQUI FORÇA O TEMA CLARO */}
      <body className={inter.className}>
        <Layout>{children}</Layout>
      </body>
    </html>
  );
}