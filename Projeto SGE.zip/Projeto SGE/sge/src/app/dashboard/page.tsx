'use client';

import { useStore } from '@/store/useStore';
import { Package, AlertTriangle, DollarSign, TrendingUp, Warehouse } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function DashboardPage() {
  const { products, movements, company } = useStore();

  const totalProdutos = products.length;
  const estoqueCritico = products.filter(p => p.quantidade === 0).length;
  const estoqueBaixo = products.filter(p => p.quantidade > 0 && p.quantidade <= p.estoque_minimo).length;
  const valorTotalEstoque = products.reduce((acc, p) => acc + (p.quantidade * p.preco_venda), 0);
  
  const movimentacoesHoje = movements.filter(m => {
    const hoje = format(new Date(), 'yyyy-MM-dd');
    return m.data.slice(0, 10) === hoje;
  }).length;

  const ultimasMovimentacoes = movements.slice(-5).reverse();

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      {/* Header */}
      <div className="mb-10">
        <h1 style={{ color: '#05204B' }} className="text-4xl font-bold">
          Bem-vindo de volta, {company.nome || 'Administrador'}!
        </h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">
          Visão geral do seu estoque • {format(new Date(), "dd 'de' MMMM 'de' yyyy, EEEE", { locale: ptBR })}
        </p>
      </div>

      {/* Cards Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-7 mb-12">
        {/* Total de Produtos */}
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: '#64748b' }} className="text-sm font-semibold">Total de Produtos</p>
              <p style={{ color: '#05204B' }} className="text-5xl font-bold mt-3">{totalProdutos}</p>
            </div>
            <div className="p-5 rounded-3xl" style={{ backgroundColor: '#4675AF' }}>
              <Package className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>

        {/* Estoque Baixo/Crítico */}
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: '#64748b' }} className="text-sm font-semibold">Estoque Baixo/Crítico</p>
              <p style={{ color: '#ef4444' }} className="text-5xl font-bold mt-3">{estoqueCritico + estoqueBaixo}</p>
              <p style={{ color: '#64748b' }} className="text-xs mt-1">{estoqueCritico} crítico • {estoqueBaixo} baixo</p>
            </div>
            <div className="p-5 rounded-3xl" style={{ backgroundColor: '#ef4444' }}>
              <AlertTriangle className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>

        {/* Valor Total em Estoque */}
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: '#64748b' }} className="text-sm font-semibold">Valor Total em Estoque</p>
              <p style={{ color: '#05204B' }} className="text-5xl font-bold mt-3">
                R$ {valorTotalEstoque.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="p-5 rounded-3xl" style={{ backgroundColor: '#10b981' }}>
              <DollarSign className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>

        {/* Movimentações Hoje */}
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: '#64748b' }} className="text-sm font-semibold">Movimentações Hoje</p>
              <p style={{ color: '#05204B' }} className="text-5xl font-bold mt-3">{movimentacoesHoje}</p>
            </div>
            <div className="p-5 rounded-3xl" style={{ backgroundColor: '#4675AF' }}>
              <TrendingUp className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Últimas Movimentações */}
      <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
        <h2 style={{ color: '#05204B' }} className="text-2xl font-bold mb-7">Últimas Movimentações</h2>

        {ultimasMovimentacoes.length === 0 ? (
          <p style={{ color: '#64748b' }} className="text-center py-12 text-lg">
            Nenhuma movimentação registrada ainda
          </p>
        ) : (
          <div className="space-y-5">
            {ultimasMovimentacoes.map((m) => (
              <div key={m.id} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0">
                <div className="flex items-center gap-5">
                  <div className={`p-4 rounded-2xl ${m.tipo === 'entrada' ? 'bg-[#10b981]/10' : 'bg-[#ef4444]/10'}`}>
                    <Warehouse className={`w-7 h-7 ${m.tipo === 'entrada' ? 'text-[#10b981]' : 'text-[#ef4444]'}`} />
                  </div>
                  <div>
                    <p style={{ color: '#05204B' }} className="font-semibold text-lg">{m.produtoNome}</p>
                    <p style={{ color: '#64748b' }} className="text-sm">
                      {format(new Date(m.data), "dd/MM/yyyy 'às' HH:mm")}
                    </p>
                  </div>
                </div>
                <span className={`font-bold text-xl ${m.tipo === 'entrada' ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                  {m.tipo === 'entrada' ? '+' : '-'}{m.quantidade}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}