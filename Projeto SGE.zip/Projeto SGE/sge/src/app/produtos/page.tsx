'use client';

import { useStore } from '@/store/useStore';
import { Package, Search, Plus, Edit, Trash2, ArrowUpDown, AlertCircle } from 'lucide-react';
import { useState } from 'react';

export default function ProdutosPage() {
  const { products, addProduct, updateProduct, deleteProduct, addMovement } = useStore();
  const [busca, setBusca] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [produtoEditando, setProdutoEditando] = useState<any>(null);
  const [movimentacaoModal, setMovimentacaoModal] = useState<any>(null);

  const [form, setForm] = useState({
    codigo: '',
    nome: '',
    categoria: '',
    estoque_minimo: 0,
    preco_custo: 0,
    preco_venda: 0,
  });

  const categorias = [...new Set(products.map(p => p.categoria).filter(Boolean))];

  const produtosFiltrados = products.filter(p => {
    const matchesBusca = p.nome.toLowerCase().includes(busca.toLowerCase()) || p.codigo.includes(busca);
    const matchesCategoria = !categoriaFiltro || p.categoria === categoriaFiltro;
    return matchesBusca && matchesCategoria;
  });

  const handleSubmitProduto = (e: React.FormEvent) => {
    e.preventDefault();
    if (produtoEditando) {
      updateProduct(produtoEditando.id, form);
    } else {
      addProduct({ ...form, quantidade: 0 });
    }
    setModalAberto(false);
    setProdutoEditando(null);
    setForm({
      codigo: '',
      nome: '',
      categoria: '',
      estoque_minimo: 0,
      preco_custo: 0,
      preco_venda: 0,
    });
  };

  const handleMovimentacao = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const quantidade = parseInt((e.target as any).quantidade.value);
    const tipo = (e.target as any).tipo.value as 'entrada' | 'saida';
    addMovement({
      produtoId: movimentacaoModal.id,
      tipo,
      quantidade,
      produtoNome: movimentacaoModal.nome,
    });
    setMovimentacaoModal(null);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      <div className="mb-10">
        <h1 style={{ color: '#000000' }} className="text-4xl font-bold">Produtos</h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">Gerencie todos os produtos do seu estoque</p>
      </div>

      <div className="bg-white rounded-3xl shadow-lg p-6 mb-8 border border-gray-100">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-4 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por nome ou código..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none text-lg"
              style={{ color: '#000000' }}
            />
          </div>
          <select
            value={categoriaFiltro}
            onChange={(e) => setCategoriaFiltro(e.target.value)}
            className="px-6 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none"
            style={{ color: '#000000' }}
          >
            <option value="">Todas as categorias</option>
            {categorias.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <button
            onClick={() => setModalAberto(true)}
            className="bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold px-8 py-4 rounded-2xl flex items-center gap-3 shadow-lg transition transform hover:scale-105"
          >
            <Plus size={24} />
            Novo Produto
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-lg overflow-hidden border border-gray-100">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead style={{ backgroundColor: '#05204B' }}>
              <tr>
                <th className="text-left p-6 text-white font-bold">Código</th>
                <th className="text-left p-6 text-white font-bold">Nome</th>
                <th className="text-left p-6 text-white font-bold">Categoria</th>
                <th className="text-center p-6 text-white font-bold">Quantidade</th>
                <th className="text-center p-6 text-white font-bold">Estoque Mín.</th>
                <th className="text-right p-6 text-white font-bold">Preço Venda</th>
                <th className="text-center p-6 text-white font-bold">Ações</th>
              </tr>
            </thead>
            <tbody>
              {produtosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-16 text-gray-500 text-lg">
                    Nenhum produto encontrado
                  </td>
                </tr>
              ) : (
                produtosFiltrados.map((p) => (
                  <tr key={p.id} className="border-t border-gray-100 hover:bg-gray-50 transition">
                    <td className="p-6 font-semibold" style={{ color: '#000000' }}>{p.codigo}</td>
                    <td className="p-6" style={{ color: '#000000' }}>{p.nome}</td>
                    <td className="p-6 text-gray-600">{p.categoria || '-'}</td>
                    <td className="p-6 text-center">
                      <span className={`inline-flex items-center px-4 py-2 rounded-full font-bold text-lg ${
                        p.quantidade === 0 ? 'bg-red-100 text-red-700' :
                        p.quantidade <= p.estoque_minimo ? 'bg-orange-100 text-orange-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {p.quantidade}
                        {p.quantidade <= p.estoque_minimo && <AlertCircle size={18} className="ml-2" />}
                      </span>
                    </td>
                    <td className="p-6 text-center text-gray-600">{p.estoque_minimo}</td>
                    <td className="p-6 text-right font-semibold" style={{ color: '#000000' }}>
                      R$ {parseFloat(p.preco_venda.toString()).toFixed(2)}
                    </td>
                    <td className="p-6 text-center">
                      <div className="flex items-center justify-center gap-3">
                        <button onClick={() => { setProdutoEditando(p); setForm(p); setModalAberto(true); }} className="p-3 rounded-xl bg-[#4675AF]/10 hover:bg-[#4675AF]/20 transition">
                          <Edit size={20} style={{ color: '#4675AF' }} />
                        </button>
                        <button onClick={() => setMovimentacaoModal(p)} className="p-3 rounded-xl bg-green-100 hover:bg-green-200 transition">
                          <ArrowUpDown size={20} className="text-green-700" />
                        </button>
                        <button onClick={() => deleteProduct(p.id)} className="p-3 rounded-xl bg-red-100 hover:bg-red-200 transition">
                          <Trash2 size={20} className="text-red-700" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Novo/Editar Produto */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl p-10 w-full max-w-2xl">
            <h2 className="text-3xl font-bold mb-8" style={{ color: '#000000' }}>
              {produtoEditando ? 'Editar Produto' : 'Novo Produto'}
            </h2>
            <form onSubmit={handleSubmitProduto} className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <input placeholder="Código" required value={form.codigo} onChange={(e) => setForm({...form, codigo: e.target.value})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
                <input placeholder="Nome" required value={form.nome} onChange={(e) => setForm({...form, nome: e.target.value})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
                <input placeholder="Categoria" value={form.categoria} onChange={(e) => setForm({...form, categoria: e.target.value})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
                <input type="number" placeholder="Estoque Mínimo" value={form.estoque_minimo} onChange={(e) => setForm({...form, estoque_minimo: parseInt(e.target.value) || 0})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
                <input type="number" step="0.01" placeholder="Preço Custo" value={form.preco_custo} onChange={(e) => setForm({...form, preco_custo: parseFloat(e.target.value) || 0})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
                <input type="number" step="0.01" placeholder="Preço Venda" required value={form.preco_venda} onChange={(e) => setForm({...form, preco_venda: parseFloat(e.target.value) || 0})} className="px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] focus:outline-none text-lg" style={{ color: '#000000' }} />
              </div>
              <div className="flex gap-4 justify-end pt-6">
                <button type="button" onClick={() => { setModalAberto(false); setProdutoEditando(null); setForm({codigo:'',nome:'',categoria:'',estoque_minimo:0,preco_custo:0,preco_venda:0}); }} className="px-10 py-4 rounded-2xl border border-gray-400 font-bold text-gray-700 hover:bg-gray-50 transition">
                  Cancelar
                </button>
                <button type="submit" className="px-10 py-4 rounded-2xl bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold shadow-lg transition">
                  {produtoEditando ? 'Salvar Alterações' : 'Cadastrar Produto'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Movimentação */}
      {movimentacaoModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl p-10 w-full max-w-md">
            <h2 className="text-3xl font-bold mb-6" style={{ color: '#000000' }}>Movimentar: {movimentacaoModal.nome}</h2>
            <form onSubmit={handleMovimentacao} className="space-y-6">
              <select name="tipo" required className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }}>
                <option value="entrada">Entrada de estoque</option>
                <option value="saida">Saída de estoque</option>
              </select>
              <input type="number" name="quantidade" placeholder="Quantidade" required min="1" className="w-full px-6 py-4 rounded-2xl border border-gray-300 focus:border-[#4675AF] text-lg" style={{ color: '#000000' }} />
              <div className="flex gap-4 justify-end pt-4">
                <button type="button" onClick={() => setMovimentacaoModal(null)} className="px-8 py-4 rounded-2xl border border-gray-400 font-bold text-gray-700 hover:bg-gray-50 transition">
                  Cancelar
                </button>
                <button type="submit" className="px-8 py-4 rounded-2xl bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold shadow-lg transition">
                  Confirmar Movimentação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}