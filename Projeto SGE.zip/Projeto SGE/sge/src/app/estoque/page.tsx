'use client';

import { useStore } from '@/store/useStore';
import { Search, Package, AlertTriangle } from 'lucide-react';
import { useState } from 'react';

export default function EstoquePage() {
  const { products } = useStore();
  const [busca, setBusca] = useState('');

  const critico = products.filter(p => p.quantidade === 0).length;
  const baixo = products.filter(p => p.quantidade > 0 && p.quantidade <= p.estoque_minimo).length;
  const normal = products.filter(p => p.quantidade > p.estoque_minimo).length;

  const produtosFiltrados = products.filter(p =>
    p.nome.toLowerCase().includes(busca.toLowerCase()) || p.codigo.includes(busca)
  );

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      <div className="mb-10">
        <h1 style={{ color: '#000000' }} className="text-4xl font-bold">Estoque</h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">Visão completa do nível de estoque</p>
      </div>

      {/* Cards Gigantes Crítico / Baixo / Normal */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100 text-center">
          <div className="w-28 h-28 mx-auto mb-6 rounded-full flex items-center justify-center" style={{ backgroundColor: '#ef4444' }}>
            <AlertTriangle size={64} className="text-white" />
          </div>
          <h2 className="text-6xl font-bold text-[#ef4444]">{critico}</h2>
          <p className="text-2xl font-semibold mt-4" style={{ color: '#000000' }}>Crítico</p>
          <p className="text-gray-600">Quantidade zerada</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100 text-center">
          <div className="w-28 h-28 mx-auto mb-6 rounded-full flex items-center justify-center" style={{ backgroundColor: '#f59e0b' }}>
            <AlertTriangle size={64} className="text-white" />
          </div>
          <h2 className="text-6xl font-bold text-[#f59e0b]">{baixo}</h2>
          <p className="text-2xl font-semibold mt-4" style={{ color: '#000000' }}>Baixo</p>
          <p className="text-gray-600">Abaixo do estoque mínimo</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-100 text-center">
          <div className="w-28 h-28 mx-auto mb-6 rounded-full flex items-center justify-center" style={{ backgroundColor: '#10b981' }}>
            <Package size={64} className="text-white" />
          </div>
          <h2 className="text-6xl font-bold text-[#10b981]">{normal}</h2>
          <p className="text-2xl font-semibold mt-4" style={{ color: '#000000' }}>Normal</p>
          <p className="text-gray-600">Estoque seguro</p>
        </div>
      </div>

      {/* Busca + Lista de Produtos */}
      <div className="bg-white rounded-3xl shadow-lg p-8 border border-gray-100">
        <div className="relative max-w-md mx-auto mb-8">
          <Search className="absolute left-4 top-4 text-gray-400" size={24} />
          <input
            type="text"
            placeholder="Buscar produtos..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full pl-14 pr-6 py-5 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none text-lg"
            style={{ color: '#000000' }}
          />
        </div>

        <div className="space-y-4">
          {produtosFiltrados.length === 0 ? (
            <p className="text-center py-12 text-gray-500 text-xl">Nenhum produto encontrado</p>
          ) : (
            produtosFiltrados.map(p => (
              <div key={p.id} className="flex items-center justify-between p-6 rounded-2xl border border-gray-200 hover:shadow-md transition">
                <div className="flex items-center gap-6">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    p.quantidade === 0 ? 'bg-red-500' :
                    p.quantidade <= p.estoque_minimo ? 'bg-orange-500' :
                    'bg-green-500'
                  }`}>
                    <Package size={32} className="text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold" style={{ color: '#000000' }}>{p.nome}</p>
                    <p className="text-gray-600">Código: {p.codigo} • Categoria: {p.categoria || 'Sem categoria'}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-4xl font-bold" style={{ color: '#000000' }}>{p.quantidade}</p>
                  <p className="text-gray-600">Estoque mínimo: {p.estoque_minimo}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}