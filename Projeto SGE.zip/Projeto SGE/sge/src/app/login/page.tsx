'use client';

import { useStore } from '@/store/useStore';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Package } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useStore();
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login();
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#FAFEFE] flex items-center justify-center px-4">
      {/* Card principal */}
      <div className="bg-white rounded-3xl shadow-2xl p-12 w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-[#4675AF] rounded-3xl mb-6 shadow-lg">
            <Package className="w-14 h-14 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-[#05204B]">SGE</h1>
          <p className="text-[#64748b] text-lg mt-2">Sistema de Gestão de Estoque</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-7">
          <div>
            <label className="block text-sm font-semibold text-[#05204B] mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-6 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none transition text-[#05204B] text-lg"
              placeholder="seu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-[#05204B] mb-2">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-6 py-4 rounded-2xl border border-gray-200 focus:border-[#4675AF] focus:outline-none transition text-[#05204B] text-lg"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#4675AF] hover:bg-[#3d66a0] text-white font-bold py-5 rounded-2xl transition transform hover:scale-[1.02] shadow-xl text-lg"
          >
            Entrar no Sistema
          </button>
        </form>

        <p className="text-center text-xs text-[#64748b] mt-10">
          SGE v1.0 • © 2025 Todos os direitos reservados
        </p>
      </div>
    </div>
  );
}