'use client';

import { useStore } from '@/store/useStore';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function RelatoriosPage() {
  const { products, movements, company } = useStore();

  // Dados para gráfico de valor em estoque por categoria
  const valorPorCategoria = products.reduce((acc, p) => {
    const cat = p.categoria || 'Sem categoria';
    const existing = acc.find(item => item.name === cat);
    const valor = p.quantidade * p.preco_venda;
    if (existing) {
      existing.value += valor;
    } else {
      acc.push({ name: cat, value: valor });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  // Dados para movimentações nos últimos 7 dias
  const ultimos7Dias = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return format(date, 'dd/MM');
  }).reverse();

  const movimentacoesPorDia = ultimos7Dias.map(day => {
    const date = day.split('/').reverse().join('-');
    const entradas = movements.filter(m => 
      m.tipo === 'entrada' && m.data.slice(0, 10).includes(date)
    ).reduce((sum, m) => sum + m.quantidade, 0);
    const saidas = movements.filter(m => 
      m.tipo === 'saida' && m.data.slice(0, 10).includes(date)
    ).reduce((sum, m) => sum + m.quantidade, 0);
    return { day, entradas, saidas, total: entradas - saidas };
  });

  const totalValorEstoque = products.reduce((acc, p) => acc + (p.quantidade * p.preco_venda), 0);

  const COLORS = ['#4675AF', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFEFE' }}>
      <div className="mb-10">
        <h1 style={{ color: '#000000' }} className="text-4xl font-bold">Relatórios</h1>
        <p style={{ color: '#64748b' }} className="mt-2 text-lg">Análise completa do seu estoque e movimentações</p>
      </div>

      {/* Cards Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <p className="text-gray-600 text-lg">Valor Total em Estoque</p>
          <p className="text-5xl font-bold mt-4" style={{ color: '#000000' }}>
            R$ {totalValorEstoque.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <p className="text-gray-600 text-lg">Total de Movimentações</p>
          <p className="text-5xl font-bold mt-4" style={{ color: '#000000' }}>{movements.length}</p>
        </div>
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <p className="text-gray-600 text-lg">Produtos Cadastrados</p>
          <p className="text-5xl font-bold mt-4" style={{ color: '#000000' }}>{products.length}</p>
        </div>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Valor por Categoria */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <h2 className="text-2xl font-bold mb-6" style={{ color: '#000000' }}>Valor em Estoque por Categoria</h2>
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={valorPorCategoria}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: R$${value.toFixed(2)}`}
                outerRadius={140}
                fill="#8884d8"
                dataKey="value"
              >
                {valorPorCategoria.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `R$${value.toFixed(2)}`} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Movimentações Últimos 7 Dias */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          <h2 className="text-2xl font-bold mb-6" style={{ color: '#000000' }}>Movimentações nos Últimos 7 Dias</h2>
          <ResponsiveContainer width="100%" heisght={400}>
            <BarChart data={movimentacoesPorDia}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="entradas" fill="#10b981" name="Entradas" />
              <Bar dataKey="saidas" fill="#ef4444" name="Saídas" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}