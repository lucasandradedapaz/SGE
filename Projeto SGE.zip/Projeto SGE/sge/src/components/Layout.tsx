'use client';

import { Home, Package, Warehouse, History, BarChart3, Settings, LogOut } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useStore } from '@/store/useStore';
import { useEffect } from 'react';

const navItems = [
  { name: 'Dashboard', href: '/dashboard', icon: Home },
  { name: 'Produtos', href: '/produtos', icon: Package },
  { name: 'Estoque', href: '/estoque', icon: Warehouse },
  { name: 'Movimentações', href: '/movimentacoes', icon: History },
  { name: 'Relatórios', href: '/relatorios', icon: BarChart3 },
  { name: 'Configurações', href: '/configuracoes', icon: Settings },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { isLoggedIn, logout } = useStore();

  useEffect(() => {
    if (!isLoggedIn && pathname !== '/login') {
      router.replace('/login');
    }
  }, [isLoggedIn, pathname, router]);

  if (pathname === '/login') {
    return <>{children}</>;
  }

  if (!isLoggedIn) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#FAFEFE]">
        <div className="text-[#05204B] text-xl font-bold">Carregando sistema...</div>
      </div>
    );
  }

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <div className="flex h-screen bg-[#FAFEFE]">
      {/* Sidebar AZUL ESCURO com letras PRETAS */}
      <div className="w-64 flex flex-col" style={{ backgroundColor: '#05204B' }}>
        <div className="p-6 border-b border-white/10">
          <h1 className="text-3xl font-bold text-black">SGE</h1>
          <p className="text-sm text-black/80 mt-1">Sistema de Gestão de Estoque</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold text-lg ${
                  isActive
                    ? 'bg-[#4675AF] text-white shadow-xl'
                    : 'text-black/90 hover:bg-white/12 hover:text-black'
                }`}
              >
                <Icon size={24} className={isActive ? 'text-white' : 'text-black/80'} />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="flex items-center gap-4 px-5 py-4 rounded-2xl text-black/90 hover:bg-white/12 hover:text-black w-full text-left font-semibold transition-all"
          >
            <LogOut size={24} className="text-black/80" />
            <span>Sair</span>
          </button>
          <p className="text-xs text-center mt-6 text-black/60">SGE v1.0</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="p-8">{children}</div>
      </div>
    </div>
  );
}