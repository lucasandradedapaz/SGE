import React from 'react'

function ServicePage() {
  return (
    <div>S</div>
  )
}

export default  ServicePage